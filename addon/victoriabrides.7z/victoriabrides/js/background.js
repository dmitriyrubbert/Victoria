﻿"use strict";


//=============== vars

var DB = chrome.storage.local;

var oPorts = {};

var oStore;

var bLogin = false;

var oProgress = {};
var oNoticeWarn = {};
var nNotice = 0;


//=============== function: var

var fInit = function(){
    bLogin = false;

    var oMen;
    var pNotice;

    while ( oMen = aMens.shift() ) {
        delete oMens[ oMen.id ];
    }

    for ( pNotice in oProgress ) {
        if ( oProgress.hasOwnProperty( pNotice ) ) {
            oProgress[ pNotice ].progress = 100;
        }
    }

    DB.set({ isLogin: false, account: [] });
};


//=============== function: storage

var fStoreInitChanged = function(){

    chrome.storage.onChanged.addListener( function( oChanges ) {
        var value;

        for ( var sAttr in oChanges ) {
            if ( oChanges.hasOwnProperty( sAttr ) ) {
                value = oChanges[ sAttr ].newValue;
                
                if ( value === undefined ) {
                    delete oStore[ sAttr ];
                } else {
                    oStore[ sAttr ] = value;
                }

                console.log( 'STORE: ' + sAttr );
            }
        }
    });
};

var fStoreSet = function() {    // f( sName, value, fCallback )  or  f( oData, fCallback )
    var fCallback;
    var obj;

    if ( arguments.length === 3 ) {
        obj = {};
        obj[ arguments[0] ] = arguments[1];
        fCallback = arguments[2];
    } else {
        obj = arguments[0];
        fCallback = arguments[1];
    }
        
    DB.set( obj, function() {
        if ( fCallback ) {
            fCallback( chrome.runtime.lastError );
        }
    });
};

var fStoreGet = function() {    // f( sName, fCallback )  or  f( fCallback )
    var fCallback;
    var sName;

    if ( arguments.length === 2 ) {
        sName = arguments[0];
        fCallback = arguments[1];
    } else {
        fCallback = arguments[0];
    }

    DB.get( sName, function( oStore ) {
        fCallback( sName ? oStore[ sName ] : oStore );
    });
};


//=============== function: notice

var fNoticeWarn = function( sId, sMsg, sTitle ) {

    if ( oNoticeWarn[ sId ] ) {

        oNoticeWarn[ sId ] = sMsg;

    } else {

        oNoticeWarn[ sId ] = sMsg;
        chrome.notifications.create(
            sId,
            {
                type     : 'basic',
                iconUrl  : chrome.extension.getURL( 'img/face128w.png' ),
                title    : 'Victoriabrides: ' + ( sTitle || 'Exception' ),
                message  : sMsg
            },
            function( id ) {
                var interval = setInterval( function() {
                    if ( oNoticeWarn[ sId ] ) {
                        chrome.notifications.update( id, { message: oNoticeWarn[ sId ] }, function( updated ) {
                            if ( !updated ) {
                                clearInterval( interval );
                                delete oNoticeWarn[ sId ];
                            }
                        });
                    } else {
                        chrome.notifications.clear( id );
                        clearInterval( interval );
                        delete oNoticeWarn[ sId ];
                    }
                }, 200 );  
            }
        );

    }
};

var fNoticeProgress = function( sId, nProgress, sMsg, sTitle ) {
    sId = sId || 'progress';

    if ( oProgress[ sId ] ) {

        oProgress[ sId ].progress = nProgress || 0;
        if ( sMsg ) oProgress[ sId ].message = sMsg;

    } else {

        oProgress[ sId ] = { progress: nProgress || 0 };
        chrome.notifications.create(
            sId,
            {
                type    : 'progress',
                iconUrl : chrome.extension.getURL( 'img/face128p.png' ),
                title   : 'Victoriabrides: ' + ( sTitle || 'Progress' ),
                message : sMsg,
                progress: 0,
            },
            function( id ) {
                var interval = setInterval( function() {
                    if ( oProgress[ sId ].progress < 100 ) {
                        chrome.notifications.update( id, oProgress[ sId ], function( updated ) {
                            if ( !updated ) {
                                clearInterval( interval );
                                delete oProgress[ sId ];
                            }
                        });
                    } else {
                        chrome.notifications.clear( id );
                        clearInterval( interval );
                        delete oProgress[ sId ];
                    }
                }, 200 );
            }
        );

    }
};

var fWarn = function( sMsg, sTitle ) {
    fNoticeWarn( 'pageWarn' + nNotice++, oMsg.warn.msg, oMsg.warn.title );
};


//=============== function

// ...


//=============== listener


chrome.tabs.onUpdated.addListener( function( id, info, tab ) {
    if ( info.status == 'complete' ) {
        if( /agency.victoriabrides.com/.test( tab.url ) ) {
            if ( oPorts[ id ] ) {
                //chrome.pageAction.hide();
            }
            chrome.pageAction.show( id );
            oPorts[ id ] = chrome.tabs.connect( id );
        } else {
            delete oPorts[ id ];
        }
    }
} );

chrome.tabs.onReplaced.addListener( function( id, oldId ) {
    oPorts[ oldId ] = oPorts[ id ];
    delete oPorts[ id ];
} );

chrome.tabs.onRemoved.addListener( function( id, removeInfo ) {
    delete oPorts[ id ];
} );

chrome.extension.onConnect.addListener( function( oPort ){
    oPort.onMessage.addListener( function( oMsg, oPort ) {

        var oPortSender = oPorts[ oPort.sender.tab.id ];

        if ( oMsg.hasOwnProperty( 'page' ) ) {

            switch( oMsg.page ) {
                case 'login':
                        fInit();
                    break;
                default:
                    console.log( 'PAGE: ' + oMsg.page );
            }

        } else if ( oMsg.hasOwnProperty( 'progress' ) ) {

            fNoticeProgress( oMsg.progress.id || 'men_load', oMsg.progress.value, oMsg.progress.msg, oMsg.progress.title );

        } else if ( oMsg.hasOwnProperty( 'warn' ) ) {

            fWarn( oMsg.warn.msg, oMsg.warn.title );

        }

    } );
} );


//=============== ready

fStoreGet( undefined, function( oStorage ) {

    if ( oStorage.template ) {

        oStore = oStorage;
        oStore.isLogin = false;
        fStoreSet( { isLogin: false, account: [] }, fStoreInitChanged );

    } else {

        oStore = {
            isLogin : false,
            template: [ [0, 'Hey %name%!'], [1, 'Hi, %name%!'], [2, 'Hello, Mr. %name%!'], [3, 'Hallo, %name%!'] ],
            account : [],
            man     : 0
        };
        fStoreSet( oStore, fStoreInitChanged );
    }
} );

