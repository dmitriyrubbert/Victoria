﻿"use strict";


//=============== vars

var oStore;
var aUsers = [];
var aTemplates = [];
var oMyGridUsersStore;
var oMyGridTemplatesStore;


//=============== function: storage

var fStoreLoadUsers = function( fCallback ){
    while ( aUsers.shift() );
    var l = Math.ceil( oStore.man / 500 );
    var aMan;
    var j;

    for ( var i = 0; i < l; ) {
        aMan = oStore[ 'man_' + i++ ];
        for ( j = 0; j < aMan.length; j++ ) {
            aUsers.push( aMan[j] );
        }
    }
    
    setTimeout( function(){ fCallback(); }, 1 );
};

var fStoreLoadTemplates = function( fCallback ){
    while ( aTemplates.shift() );

    for ( var i = 0; i < oStore.template.length; ) {
        aTemplates.push( oStore.template[i++] );
    }
    
    setTimeout( function(){ fCallback(); }, 1 );
};


//=============== listener

window.addEventListener( 'message', function( evt ) {
    var oMsg = evt.data;

    if ( oMsg.hasOwnProperty( 'store' ) ) {
        oStore = oMsg.store;
        fStoreLoadTemplates( function() {
            if ( oMyGridUsersStore ) {
                oMyGridTemplatesStore.reload();
            }
            fStoreLoadUsers( function(){
                if ( oMyGridUsersStore ) {
                    oMyGridUsersStore.reload();
                }
            });
        });
    }
} );


//=============== ready

$( document ).ready( function() {

    Ext.define( 'MyGridTemplatesModel', {
        extend: 'Ext.data.Model',
        fields: [
            { name: 'message', type: 'string' }
        ]
    });

    Ext.define( 'MyGridUsersModel', {
        extend: 'Ext.data.Model',
        idProperty: 'id',
        fields: [
            { name: 'id', type: 'int' },
            { name: 'name', type: 'string' },
            { name: 'age', type: 'int' },
            { name: 'country', type: 'string' },
            { name: 'city', type: 'string' },
            { name: 'premium', type: 'boolean' },
            { name: 'last', type: 'date' }
        ]
    });

    oMyGridUsersStore = Ext.create( 'Ext.data.Store', {
        model: 'MyGridUsersModel',
        data : { man: aUsers },
        pageSize: 40,
        proxy: {
            enablePaging: true,
            type: 'memory',
            reader: {
                type: 'array',
                root: 'man'
            }
        }
    });

    oMyGridTemplatesStore = Ext.create( 'Ext.data.Store', {
        model: 'MyGridTemplatesModel',
        data : { template: aTemplates },
        pageSize: 40,
        proxy: {
            enablePaging: true,
            type: 'memory',
            reader: {
                type: 'array',
                root: 'template'
            }
        }
    });

    Ext.define( 'MyGridUsers', {
        extend      : 'Ext.grid.Panel',
        alias       : 'widget.mygridusers',
        store       : oMyGridUsersStore,
        stateful    : true,
        viewConfig  : {
            forceFit: true
        },
        dockedItems: [{
            xtype      : 'pagingtoolbar',
            store      : oMyGridUsersStore,
            dock       : 'bottom',
            displayInfo: true
        }],
        columns     : [
            {
                text     : 'Id',
                dataIndex: 'id',
                width    : 70
            },
            {
                text     : 'Name',
                dataIndex: 'name',
                flex     : 2
            },
            {
                text     : 'Age',
                dataIndex: 'age',
                width    : 40
            },
            {
                text     : 'Country',
                dataIndex: 'country',
                flex     : 1
            },
            {
                text     : 'City',
                dataIndex: 'city',
                flex     : 1
            },
            {
                text     : 'Last visit',
                dataIndex: 'last',
                renderer : Ext.util.Format.dateRenderer('d.m.Y'),
                width    : 80
            },
            {
                text     : 'Premium',
                dataIndex: 'premium',
                xtype    : 'checkcolumn',
                renderer : function( value ) {
                    return '<div class="grid-colum-check grid-colum-' + ( value ? 'yes' : 'no' ) + '" />';
                },
                processEvent: function() {
                    return false;
                },
                width    : 55
            }
        ]
    });

    Ext.define( 'MyGridTemplates', {
        extend      : 'Ext.grid.Panel',
        alias       : 'widget.mygridtemplates',
        store       : oMyGridTemplatesStore,
        stateful    : true,
        viewConfig  : {
            forceFit: true
        },
        dockedItems: [{
            xtype      : 'pagingtoolbar',
            store      : oMyGridUsersStore,
            dock       : 'bottom',
            displayInfo: true
        }],
        columns     : [{
            text     : 'Message',
            dataIndex: 'message',
            width    : '100%'
        }]
    });

    Ext.create( 'Ext.tab.Panel', {
        renderTo: 'panel',
        width   : '100%',
        height  : '100%',
        plain   : true,
        items: [
            {
                title: 'Templates',
                layout: 'border',
                items:[{
                    region: 'center',
                    title: 'List',
                    split: true,
                    xtype: 'mygridtemplates'
                }, {
                    region: 'east',
                    title: 'Edit',
                    collapsible: true,
                    split: true,
                    minWidth: 250
                }]
            }, {
                title: 'Mans',
                xtype: 'mygridusers'
            }
        ]
    });

    setTimeout( function(){
        parent.postMessage( { key: 'init' }, '*' );
    }, 1000 );

});

