﻿
(function(){
    "use strict";


    //=============== vars

    var self = this;

    var DB = chrome.storage.local;

    var oUrl = {
        path :  window.location.pathname,
        href :  window.location.href,
        hash :  window.location.hash,
    };

    var oPort = chrome.extension.connect();

    var oStore;
    var bUsers = false;
    var aUsers = [];

    var oWin = {};

    var sSearch = 'Search for mailing';

    var oGrid;
    var sGridId;
    var oGridStore;


    //=============== function: storage

    var fStoreSet = function() {    // f( sName, value, fCallback )  or  f( oData, fCallback )
        var fCallback;
        var obj;

        if ( arguments.length === 3 ) {
            obj = {};
            obj[ arguments[0] ] = arguments[1];
            fCallback = arguments[2];
        } else {
            obj = arguments[0];
            fCallback = arguments[1];
        }
            
        DB.set( obj, function() {
            if ( fCallback ) {
                fCallback( chrome.runtime.lastError );
            }
        });
    };

    var fStoreGet = function() {    // f( sName, fCallback )  or  f( fCallback )
        var fCallback;
        var sName;

        if ( arguments.length === 2 ) {
            sName = arguments[0];
            fCallback = arguments[1];
        } else {
            fCallback = arguments[0];
        }

        DB.get( sName, function( oStore ) {
            fCallback( sName ? oStore[ sName ] : oStore );
        });
    };

    var fStoreInitChanged = function(){
        var value;

        chrome.storage.onChanged.addListener( function( oChanges ) {
            for ( var sAttr in oChanges ) {
                if ( oChanges.hasOwnProperty( sAttr ) ) {
                    value = oChanges[ sAttr ].newValue;
                    
                    if ( value === undefined ) {
                        delete oStore[ sAttr ];
                    } else if ( sAttr.indexOf( 'man_' ) < 0 || bUsers ) {
                        oStore[ sAttr ] = value;
                    }
                }
            }
        });
    };

    var fStoreLoadUsers = function( fCallback ){
        bUsers = true;

        while ( aUsers.shift() );
        var l = Math.ceil( oStore.man / 500 );
        var i = 0;
        var j;
        
        function get(){
            if ( i < l ) {
                fStoreGet( 'man_' + i++, function( aMan ) {
                    for ( j = 0; j < aMan.length; j++ ) {
                        aUsers.push( aMan[j] );
                    }
                    get();
                });
            } else {
                fCallback();
            }
        }
        get();
    };


    //=============== function: notice

    var fNoticeProgress = function( sId, nProgress, sMsg, sTitle ) {
        oPort.postMessage({ progress: { id: sId, value: nProgress, msg: sMsg, title: sTitle } });
    };


    //=============== function: progress

    var fProgressInit = function( nProgress, sMsg ) {
        fNoticeProgress( 'init', nProgress, sMsg, 'Инициализация' );
    };

    var fProgressSearch = function( nProgress, sMsg ) {
        fNoticeProgress( 'user_search', nProgress, sMsg, 'Поиск мужчин' );
    };


    //=============== function: other

    var lng = function( sName ) {
        return chrome.i18n.getMessage( sName );
    };

    var waitEl = function( sReg, fCallback ) {
        try {
            var jEl = $( sReg );

            if ( !jEl.length ) {
                setTimeout( function(){ waitEl( sReg, fCallback ); }, 100 );
                return;
            }

            fCallback( null, jEl );
        } catch(e) {
            fCallback( e );
        }
    };

    var warn = function( sMsg, sTitle ) {
        oPort.postMessage({ warn: { msg: sMsg, title: sTitle } });
    };

    var getRnd = function( nMin, nMax ) {
        return Math.floor( nMin + Math.random() * ( nMax + 1 - nMin ) );
    };

    //=============== function: load

    var fLoadAccount = function( fCallback ) {
        if ( oStore.isLogin ) {
            fCallback();
        } else {

            try {
                $.ajax({
                    url: '/operator/find-females',
                    method: 'POST',
                }).done( function( data ) {
                    
                    fStoreSet( 'account', data.data.list, function() {
                        fCallback();
                    });

                }).fail( function( jqXHR, textStatus, errorThrown ) {
                    warn( lng('err_ajax_operator') + ': ' + textStatus );
                    fCallback();
                });

            } catch(e) {
                warn( lng('err_ajax_operator') + ': ' + e.name + ': ' + e.message );
                fCallback();
            }

        }
    };


    //=============== function: win

    var fWinSearch = function( oFilter ) {
        if ( oWin[ 'search' ] ) {
        } else {
            Ext.define( 'MyModelGrid', {
                extend: 'Ext.data.Model',
                idProperty: 'id',
                fields: [
                    { name: 'id', type: 'int' },
                    { name: 'name', type: 'string' },
                    { name: 'age', type: 'int' },
                    { name: 'country', type: 'string' },
                    { name: 'city', type: 'string' },
                    { name: 'premium', type: 'boolean' },
                    { name: 'last', type: 'date' }
                ]
            });
            var oGridStore = Ext.create( 'Ext.data.Store', {
                model: 'MyModelGrid',
                data : { man: aUsers },
                pageSize: 15,
                proxy: {
                    enablePaging: true,
                    type: 'memory',
                    reader: {
                        type: 'array',
                        root: 'man'
                    }
                }
            });
            var oGrid = Ext.create( 'Ext.grid.Panel', {
                store       : oGridStore,
                stateful    : true,
                collapsible : false,
                width       : 600,
                height      : 400,
                viewConfig  : {
                    forceFit: true
                },
                dockedItems : [{
                    xtype      : 'pagingtoolbar',
                    store      : oGridStore,
                    dock       : 'bottom',
                    displayInfo: true
                }],
                columns     : [
                    {
                        text     : 'Id',
                        dataIndex: 'id',
                        width    : 70
                    },
                    {
                        text     : 'Name',
                        dataIndex: 'name',
                        flex     : 1
                    },
                    {
                        text     : 'Age',
                        dataIndex: 'age',
                        width    : 40
                    },
                    {
                        text     : 'Country',
                        dataIndex: 'country',
                        flex     : 2
                    },
                    {
                        text     : 'Last visit',
                        dataIndex: 'last',
                        renderer : Ext.util.Format.dateRenderer('d.m.Y'),
                        width    : 80
                    },
                    {
                        text     : 'Premium',
                        dataIndex: 'premium',
                        xtype    : 'checkcolumn',
                        renderer : function( value ) {
                            return '<div class="grid-colum-check grid-colum-' + ( value ? 'yes' : 'no' ) + '" />';
                        },
                        processEvent: function() {
                            return false;
                        },
                        width    : 55
                    }
                ],
                renderTo: sGridId
            });
        }
    };


    //=============== function: path

    //  ->  /account/index/
    var pathAccountIndex = function( fCallback ) {

        waitEl( 'td:contains("Id user")', function( er, el ) {
            if ( er ) return fCallback( warn( er ) );

            fLoadAccount( fCallback );
        });
    };

    //  ->  /account/search-user
    var pathSearchUser = function( fCallback ) {

        waitEl( 'button:contains("Search males")', function( er, jButtonSearch ) {
            if ( er ) return fCallback( warn( er ) );

            try {
                sGridId = 'victoriabrides_grid_' + getRnd( 10, 5000 );

                var jBox = jButtonSearch.parent().parent();
                jBox.css({ right:'0px', width:'600px' });
                $( '<div id="' + sGridId + '" style="width:100%;height:400px;margin-top:20px;"></div>' ).appendTo( jBox );

                var jButtonStorage = $( '<button type="button" class="btn btn-default" style="margin-right:1em;">' + sSearch + '</button>' );
                jButtonSearch.before( jButtonStorage );

                jButtonStorage.click( function() {

                    waitEl( 'legend:contains("Search filters")', function( er, oLegend ) {
                        // TODO: fProgressSearch( 0 );

                        if ( jButtonStorage.text() == sSearch ) {

                            var aLi = oLegend.parent().find('ul li');
                            var oFilter = {};
                            var attr;

                            if ( aLi.length >= 1 && aLi.text() !== 'no filters' ) {
                                for ( var i = 0; i < aLi.length; i++ ) {

                                    attr = $( aLi[i] ).text().slice(0,-8).trim().replace(/\n/g,'').replace(/  /g,' ').split('=');
                                    attr[0] = attr[0].trim().toLowerCase().split(' ').reduce( function(res,str,i){ return res + ( 0 < i ? str.toUpperFirst() : str ); }, '' );
                                    try {
                                        attr[1] = JSON.parse( attr[1] );
                                    } catch(e) {
                                        try {
                                            attr[1] = attr[1].trim();
                                        }catch(e){}
                                    }
                                    oFilter[ attr[0] ] = attr[1];

                                }
                            }

                            fWinSearch( oFilter );

                        } else {
                            jButtonStorage.text( sSearch );
                        }
                    });

                });

                fCallback();
            } catch(e) {
                warn( lng('err_ajax_operator') + ': ' + e.name + ': ' + e.message );
                fCallback();
            }
        });

    };


    //=============== listener

    chrome.extension.onConnect.addListener( function( oPort ){
        oPort.onMessage.addListener( function( oMsg, oPort ) {

            

        } );
    } );


    //=============== ready

    fProgressInit( 10, 'Загрузка страницы' );
    $( document ).ready( function() {

        fProgressInit( 25, 'Загрузка кэша' );
        DB.get( [ 'isLogin', 'account', 'man' ], function( oStorage ) {
            oStore = oStorage;
            fStoreInitChanged();

            fProgressInit( 75, 'Инициализация интерфейса' );

            if ( /#login/.test( oUrl.hash ) ) {                             //  ->  /#login

                oPort.postMessage({ page: 'login' });
                setTimeout( function(){ fProgressInit( 100 ); }, 500 );

            } else if ( /account\/search-user/.test( oUrl.path ) ) {        //  ->  /account/search-user

                pathSearchUser( function() {
                    fLoadAccount( function() {
                        oPort.postMessage({ page: 'search-users' });
                        fStoreLoadUsers( function(){
                            fProgressInit( 100 );
                            fWinSearch();
                        } );
                    } );
                } );

            } else if ( /account($|\/index)/.test( oUrl.path ) ) {          //  ->  /account/index

                pathAccountIndex( function() {
                    oPort.postMessage({ page: 'account' });
                    fProgressInit( 100 );
                } );

            } else {
                fProgressInit( 100 );
            }

        } );

    } );

    

})();

