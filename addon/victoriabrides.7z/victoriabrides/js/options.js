"use strict";


var DB = chrome.storage.local;
var iframeWindow;

window.addEventListener( 'message', function( evt ) {
    var oMsg = evt.data;

    if ( oMsg.hasOwnProperty( 'key' ) ) {
        switch( oMsg.key ) {
            case 'init':
                    if ( iframeWindow ) {
                        DB.get( function( oStorage ) {
                            iframeWindow.postMessage( { store: oStorage }, '*' );
                        } );
                    }
                break;
        }
    }
} );


$( document ).ready( function() {

    var iframe = document.getElementById( 'sandbox-frame' );
    iframeWindow = iframe.contentWindow;

});
